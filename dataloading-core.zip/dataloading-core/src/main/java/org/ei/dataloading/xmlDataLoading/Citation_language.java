package org.ei.dataloading.xmlDataLoading;

public class Citation_language extends BaseElement
{
	String citation_language;
	String citation_language_lang;

	public void setCitation_language(String citation_language)
	{
		this.citation_language = citation_language;
	}

	public String getCitation_language()
	{
		return citation_language;
	}

	public void setCitation_language_lang(String citation_language_lang)
	{
		this.citation_language_lang = citation_language_lang;
	}

	public String getCitation_language_lang()
	{
		return citation_language_lang;
	}
}
