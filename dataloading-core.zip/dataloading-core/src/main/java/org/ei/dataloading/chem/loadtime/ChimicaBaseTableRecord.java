package org.ei.dataloading.chem.loadtime;


public class ChimicaBaseTableRecord
{

    public static final String[] baseTableFields = {"M_ID","ID","CHN","HST","TIE","AUT","CNA","ADR","JTA","STI","PYR","VIP","REF","COD","ISS","CNS","LNA","LNS","CTM","CRD","TRC","STD","ITD","PII","SPD","EML","MNF","TNV","MNV","TNM","MSN","TIF","PUB","EIPT","CPX","CFN","CFL","CFD","CFA","CCC","ABS","LOAD_NUMBER"};

}
