package org.ei.dataloading.xmlDataLoading;

public class Abstract_language extends BaseElement
{
	String abstract_language;
	String abstract_language_lang;

	public void setAbstract_language(String abstract_language)
	{
		this.abstract_language = abstract_language;
	}

	public String getAbstract_language()
	{
		return abstract_language;
	}

	public void setAbstract_language_lang(String abstract_language_lang)
	{
		this.abstract_language_lang = abstract_language_lang;
	}

	public String getAbstract_language_lang()
	{
		return abstract_language_lang;
	}
}
