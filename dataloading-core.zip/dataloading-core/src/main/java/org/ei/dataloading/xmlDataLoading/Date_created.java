package org.ei.dataloading.xmlDataLoading;

public class Date_created extends BaseElement
{
	String date_created;
	String date_created_year;
	String date_created_month;
	String date_created_day;


	public void setDate_created(String date_created)
	{
		this.date_created = date_created;
	}

	public String getDate_created()
	{
		return this.date_created;
	}

	public void setDate_created_year(String date_created_year)
	{
		this.date_created_year = date_created_year;
	}

	public String getDate_created_year()
	{
		return this.date_created_year;
	}

	public void setDate_created_month(String date_created_month)
	{
		this.date_created_month = date_created_month;
	}

	public String getDate_created_month()
	{
		return this.date_created_month;
	}

	public void setDate_created_day(String date_created_day)
	{
		this.date_created_day = date_created_day;
	}

	public String getDate_created_day()
	{
		return this.date_created_day;
	}

}
