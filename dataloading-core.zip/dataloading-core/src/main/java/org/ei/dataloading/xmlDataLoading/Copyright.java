package org.ei.dataloading.xmlDataLoading;

public class Copyright extends BaseElement
{

	String copyright;
	String copyright_type;
	public void setCopyright(String copyright)
	{
		this.copyright = copyright;
	}

	public String getCopyright()
	{
		return copyright;
	}

	public void setCopyright_type(String copyright_type)
	{
		this.copyright_type = copyright_type;
	}

	public String getCopyright_type()
	{
		return copyright_type;
	}
}
