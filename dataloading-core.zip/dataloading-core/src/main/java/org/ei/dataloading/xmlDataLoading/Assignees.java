package org.ei.dataloading.xmlDataLoading;

public class Assignees extends BaseElement
{
	String assignees;

	public void setAssignees(String assignees)
	{
		this.assignees = assignees;
	}

	public String getAssignees()
	{
		return this.assignees;
	}

}

