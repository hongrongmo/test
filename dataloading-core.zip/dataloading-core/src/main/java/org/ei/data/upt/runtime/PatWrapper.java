package org.ei.data.upt.runtime;

import org.ei.domain.*;

public class PatWrapper {
    public DocID did;
    public int pdate;
}