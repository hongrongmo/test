package org.ei.data.inspec.runtime;

import org.ei.domain.*;


public class InspecWrapper
{
	public EIDoc eiDoc;
	public String mid;
}