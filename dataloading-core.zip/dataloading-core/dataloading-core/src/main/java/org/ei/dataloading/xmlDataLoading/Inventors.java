package org.ei.dataloading.xmlDataLoading;

public class Inventors extends BaseElement
{
	String inventor;

	public void setInventor(String inventor)
	{
		this.inventor = inventor;
	}

	public String getInventor()
	{
		return this.inventor;
	}

}

