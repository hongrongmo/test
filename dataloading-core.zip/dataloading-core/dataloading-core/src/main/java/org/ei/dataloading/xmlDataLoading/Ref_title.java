package org.ei.dataloading.xmlDataLoading;

public class Ref_title extends BaseElement
{
	String ref_titletext;

	public void setRef_titletext(String ref_titletext)
	{
		this.ref_titletext = ref_titletext;
	}

	public String getRef_titletext()
	{
		return this.ref_titletext;
	}

}
