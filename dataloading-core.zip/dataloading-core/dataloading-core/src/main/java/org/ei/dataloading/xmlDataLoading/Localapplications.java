package org.ei.dataloading.xmlDataLoading;

public class Localapplications
{
	String localapplication;

	public void setLocalapplication(String localapplication)
	{
		this.localapplication = localapplication;
	}

	public String getLocalapplication()
	{
		return this.localapplication;
	}

}

