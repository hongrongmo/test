package org.ei.dataloading.xmlDataLoading;

public class Ref_publicationyear extends BaseElement
{

	String ref_publicationyear;
	String ref_publicationyear_first;
	String ref_publicationyear_last;


	public void setRef_publicationyear(String ref_publicationyear)
	{
		this.ref_publicationyear = ref_publicationyear;
	}

	public String getRef_publicationyear()
	{
		return ref_publicationyear;
	}

	public void setRef_publicationyear_first(String ref_publicationyear_first)
	{
		this.ref_publicationyear_first = ref_publicationyear_first;
	}

	public String getRef_publicationyear_first()
	{
		return ref_publicationyear_first;
	}

	public void setRef_publicationyear_last(String ref_publicationyear_last)
	{
		this.ref_publicationyear_last = ref_publicationyear_last;
	}

	public String getRef_publicationyear_last()
	{
		return ref_publicationyear_last;
	}


}
