package org.ei.dataloading.xmlDataLoading;

public class Tail extends BaseElement
{
	Bibliography bibliography;

	public void setBibliography(Bibliography bibliography)
	{
		this.bibliography = bibliography;
	}

	public Bibliography getBibliography()
	{
		return bibliography;
	}



}
