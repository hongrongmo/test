package org.ei.dataloading.xmlDataLoading;

public class Sectiontitle extends BaseElement
{
	String sectiontitle;
	String sectiontitle_type;

	public void setSectiontitle(String sectiontitle)
	{
		this.sectiontitle = sectiontitle;
	}

	public String getSectiontitle()
	{
		return sectiontitle;
	}

	public void setSectiontitle_type(String sectiontitle_type)
	{
		this.sectiontitle_type = sectiontitle_type;
	}

	public String getSectiontitle_type()
	{
		return sectiontitle_type;
	}
}
