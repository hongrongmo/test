package org.ei.dataloading.inspec.loadtime;


public class NoSuchSubFieldException extends Exception {
    public  NoSuchSubFieldException() {}
    public  NoSuchSubFieldException(String s) {
	super(s);
    }
}
