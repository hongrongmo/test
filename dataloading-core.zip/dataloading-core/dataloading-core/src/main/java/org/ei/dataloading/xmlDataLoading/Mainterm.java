package org.ei.dataloading.xmlDataLoading;

public class Mainterm extends BaseElement
{
	String mainterm;
	String mainterm_weight;
	String mainterm_candidate;
	String mainterm_sort_pos;
	String mainterm_code;

	public void setMainterm(String mainterm)
	{
		this.mainterm = mainterm;
	}

	public String getMainterm()
	{
		return this.mainterm;
	}

	public void setMainterm_weight(String mainterm_weight)
	{
		this.mainterm_weight = mainterm_weight;
	}

	public String getMainterm_weight()
	{
		return this.mainterm_weight;
	}

	public void setMainterm_candidate(String mainterm_candidate)
	{
		this.mainterm_candidate = mainterm_candidate;
	}

	public String getMainterm_candidate()
	{
		return this.mainterm_candidate;
	}

	public void setMainterm_sort_pos(String mainterm_sort_pos)
	{
		this.mainterm_sort_pos = mainterm_sort_pos;
	}

	public String getMainterm_sort_pos()
	{
		return this.mainterm_sort_pos;
	}

	public void setMainterm_code(String mainterm_code)
	{
		this.mainterm_code = mainterm_code;
	}

	public String getMainterm_code()
	{
		return this.mainterm_code;
	}


}
