package org.ei.dataloading.encompasspat.stn;


public class AtomicBaseTableRecord {

	public static final String[] baseTableFields = { "M_ID","DN","IN","CS","TI","TI2","PRI","AJ","AC","AD","AP","PC","PD","PN","PAT","LA","PY","DS","IC","LL","EY","CC","DT","CR","LTM","ATM1","ATM","ALC","AMS","APC","ANC","AT","CT","CRN","LT","UT","AS","LOAD_NUMBER"};
	//public static final String[] baseTableFields = { "M_ID","DN","IN","CS","TI","TI2","PRI","AJ","AC","AD","AP","PC","PD","PN","PAT","LA","PY","DS","IC","LL","EY","CC","DT","CR","ATM1","ATM","ALC","AMS","APC","ANC","AT_API","CT","CRN","UT","AS","LN"};

}
