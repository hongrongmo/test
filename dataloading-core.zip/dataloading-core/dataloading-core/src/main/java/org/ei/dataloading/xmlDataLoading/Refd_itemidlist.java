package org.ei.dataloading.xmlDataLoading;

public class Refd_itemidlist extends BaseElement
{
	String itemid;
	public void setItemid(String itemid)
	{
		this.itemid = itemid;
	}

	public String getItemid()
	{
		return this.itemid;
	}
}
