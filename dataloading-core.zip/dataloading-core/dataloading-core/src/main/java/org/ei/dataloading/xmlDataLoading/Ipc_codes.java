package org.ei.dataloading.xmlDataLoading;

public class Ipc_codes extends BaseElement
{
	String ipc_code;

	public void setIpc_code(String ipc_code)
	{
		this.ipc_code = ipc_code;
	}

	public String getIpc_code()
	{
		return this.ipc_code;
	}

}

