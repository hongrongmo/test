package org.ei.dataloading.xmlDataLoading;

public class Formatinfo extends BaseElement
{
	String formatinfo;
	String formatinfo_type;

	public void setFormatinfo(String formatinfo)
	{
		this.formatinfo = formatinfo;
	}

	public String getFormatinfo()
	{
		return formatinfo;
	}

	public void setFormatinfo_type(String formatinfo_type)
	{
		this.formatinfo_type = formatinfo_type;
	}

	public String getFormatinfo_type()
	{
		return formatinfo_type;
	}
}
