package org.ei.dataloading.xmlDataLoading;

public class Voliss extends BaseElement

{
	String voliss;
	String voliss_volume;
	String voliss_issue;

	public void setVoliss(String voliss)
	{

		this.voliss = voliss;
	}

	public String getVoliss()
	{
		return this.voliss;
	}

	public void setVoliss_volume(String voliss_volume)
	{
		this.voliss_volume = voliss_volume;
	}

	public String getVoliss_volume()
	{
		return this.voliss_volume;
	}

	public void setVoliss_issue(String voliss_issue)
	{
		this.voliss_issue = voliss_issue;
	}

	public String getVoliss_issue()
	{
		return this.voliss_issue;
	}
}
