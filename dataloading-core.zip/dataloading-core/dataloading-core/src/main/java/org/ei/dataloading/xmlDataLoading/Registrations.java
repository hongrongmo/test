package org.ei.dataloading.xmlDataLoading;

public class Registrations extends BaseElement
{
	String registration;

	public void setRegistration(String registration)
	{
		this.registration = registration;
	}

	public String getRegistration()
	{
		return this.registration;
	}

}

