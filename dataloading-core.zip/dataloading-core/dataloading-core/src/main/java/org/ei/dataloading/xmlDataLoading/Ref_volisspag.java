package org.ei.dataloading.xmlDataLoading;

public class Ref_volisspag extends BaseElement
{
	String voliss;
	String voliss_volume;
	String voliss_issue;
	String pagerange;
	String pagerange_first;
	String pagerange_last;
	String pages;
	String pagecount_type;
	String pagecount;

	public void setVoliss(String voliss)
	{
		this.voliss = voliss;
	}

	public String getVoliss()
	{
		return this.voliss;
	}

	public void setVoliss_volume(String voliss_volume)
	{
		this.voliss_volume = voliss_volume;
	}

	public String getVoliss_volume()
	{
		return this.voliss_volume;
	}

	public void setVoliss_issue(String voliss_issue)
	{
		this.voliss_issue = voliss_issue;
	}

	public String getVoliss_issue()
	{
		return this.voliss_issue;
	}

	public void setPagerange(String pagerange)
	{
		this.pagerange = pagerange;
	}

	public String getPagerange()
	{
		return this.pagerange;
	}

	public void setPagerange_first(String pagerange_first)
	{
		this.pagerange_first = pagerange_first;
	}

	public String getPagerange_first()
	{
		return this.pagerange_first;
	}

	public void setPagerange_last(String pagerange_last)
	{
		this.pagerange_last = pagerange_last;
	}

	public String getPagerange_last()
	{
		return this.pagerange_last;
	}

	public void setPages(String pages)
	{
		this.pages = pages;
	}

	public String getPages()
	{
		return this.pages;
	}

	public void setPagecount(String pagecount)
	{
		this.pagecount = pagecount;
	}

	public String getPagecount()
	{
		return this.pagecount;
	}

	public void setPagecount_type(String pagecount_type)
	{
		this.pagecount_type = pagecount_type;
	}

	public String getPagecount_type()
	{
		return this.pagecount_type;
	}

}
