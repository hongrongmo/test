package org.ei.dataloading.xmlDataLoading;

public class Sourcetitle extends BaseElement
{
	String sourcetitle;
	String sourcetitle_lang;

    public void setSourcetitle(String sourcetitle)
	{
		this.sourcetitle = sourcetitle;
	}

	public String getSourcetitle()
	{
		return this.sourcetitle;
	}

	public void setSourcetitle_lang(String sourcetitle_lang)
	{
		this.sourcetitle_lang = sourcetitle_lang;
	}

	public String getSourcetitle_lang()
	{
		return this.sourcetitle_lang;
	}
}
