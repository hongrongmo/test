
package org.ei.dataloading.inspec.loadtime;

public class NoSuchFieldException extends Exception {
    public  NoSuchFieldException() {}
    public  NoSuchFieldException(String s) {
	super(s);
    }
}
