package org.ei.dataloading.xmlDataLoading;

public class Date_completed extends BaseElement
{
	String date_completed;
	String date_completed_year;
	String date_completed_month;
	String date_completed_day;


	public void setDate_completed(String date_completed)
	{
		this.date_completed = date_completed;
	}

	public String getDate_completed()
	{
		return this.date_completed;
	}

	public void setDate_completed_year(String date_completed_year)
	{
		this.date_completed_year = date_completed_year;
	}

	public String getDate_completed_year()
	{
		return this.date_completed_year;
	}

	public void setDate_completed_month(String date_completed_month)
	{
		this.date_completed_month = date_completed_month;
	}

	public String getDate_completed_month()
	{
		return this.date_completed_month;
	}

	public void setDate_completed_day(String date_completed_day)
	{
		this.date_completed_day = date_completed_day;
	}

	public String getDate_completed_day()
	{
		return this.date_completed_day;
	}

}
