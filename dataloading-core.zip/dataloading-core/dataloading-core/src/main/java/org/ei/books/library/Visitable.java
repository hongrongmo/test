package org.ei.books.library;

public interface Visitable {
	 public void accept(Visitor visitor);
}
