package org.ei.dataloading.xmlDataLoading;

public class Publicationyear extends BaseElement
{

	String publicationyear;
	String publicationyear_first;
	String publicationyear_last;

	public void setPublicationyear(String publicationyear)
	{
		this.publicationyear = publicationyear;
	}

	public String getPublicationyear()
	{
		return publicationyear;
	}

	public void setPublicationyear_first(String publicationyear_first)
	{
		this.publicationyear_first = publicationyear_first;
	}

	public String getPublicationyear_first()
	{
		return publicationyear_first;
	}

	public void setPublicationyear_last(String publicationyear_last)
	{
		this.publicationyear_last = publicationyear_last;
	}

	public String getPublicationyear_last()
	{
		return publicationyear_last;
	}


}
