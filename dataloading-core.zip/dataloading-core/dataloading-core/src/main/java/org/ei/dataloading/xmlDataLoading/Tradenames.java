package org.ei.dataloading.xmlDataLoading;

public class Tradenames extends BaseElement
{
	Trademanuitem trademanuitem;

	public void setTrademanuitem(Trademanuitem trademanuitem)
	{
		this.trademanuitem = trademanuitem;
	}

	public Trademanuitem getTrademanuitem()
	{
		return this.trademanuitem;
	}

}
