package org.ei.dataloading.xmlDataLoading;

public class Enddate extends BaseElement
{

	String enddate;
	String enddate_year;
	String enddate_month;
	String enddate_day;

	public void setEnddate(String enddate)
	{
		this.enddate = enddate;
	}

	public String getEnddate()
	{
		return enddate;
	}

	public void setEnddate_year(String enddate_year)
	{
		this.enddate_year = enddate_year;
	}

	public String getEnddate_year()
	{
		return enddate_year;
	}

	public void setEnddate_month(String enddate_month)
	{
		this.enddate_month = enddate_month;
	}

	public String getEnddate_month()
	{
		return enddate_month;
	}

	public void setEnddate_day(String enddate_day)
	{
		this.enddate_day = enddate_day;
	}

	public String getEnddate_day()
	{
		return enddate_day;
	}




}
