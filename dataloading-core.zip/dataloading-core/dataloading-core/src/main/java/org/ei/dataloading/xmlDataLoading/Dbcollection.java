package org.ei.dataloading.xmlDataLoading;

public class Dbcollection extends BaseElement
{

	String dbcollection;

	public void setDbcollection(String dbcollection)
	{
		this.dbcollection = dbcollection;
	}

	public String getDbcollection()
	{
		return dbcollection;
	}
}
