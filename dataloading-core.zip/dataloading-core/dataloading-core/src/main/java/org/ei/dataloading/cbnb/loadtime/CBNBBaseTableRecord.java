package org.ei.dataloading.cbnb.loadtime;


public class CBNBBaseTableRecord
{
    public static String[] baseTableFields = {"M_ID", "ABN", "CDT", "DOC", "SCO", "FJL","ISN", "CDN", "LAN", "VOL", "ISS", "IBN", "PBR", "PAD", "PAG", "PBD", "PBN", "SRC", "SCT", "SCC", "EBT", "CIN", "REG", "CYM", "SIC", "GIC", "GID", "ATL", "OTL", "EDN", "AVL", "CIT", "ABS", "PYR","LOAD_NUMBER"};

}
