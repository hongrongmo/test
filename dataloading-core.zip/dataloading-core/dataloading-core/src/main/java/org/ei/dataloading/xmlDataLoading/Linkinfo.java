package org.ei.dataloading.xmlDataLoading;

public class Linkinfo extends BaseElement
{
	String linkinfo;
	String linkinfo_type;

	public void setLinkinfo(String linkinfo)
	{
		this.linkinfo = linkinfo;
	}

	public String getLinkinfo()
	{
		return linkinfo;
	}

	public void setLinkinfo_type(String linkinfo_type)
	{
		this.linkinfo_type = linkinfo_type;
	}

	public String getLinkinfo_type()
	{
		return linkinfo_type;
	}
}
