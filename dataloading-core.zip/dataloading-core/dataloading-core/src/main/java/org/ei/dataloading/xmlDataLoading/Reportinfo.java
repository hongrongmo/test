package org.ei.dataloading.xmlDataLoading;

public class Reportinfo extends BaseElement
{
	String reportnumber;

	public void setReportnumber(String reportnumber)
	{
		this.reportnumber = reportnumber;
	}

	public String getReportnumber()
	{
		return this.reportnumber;
	}

}

