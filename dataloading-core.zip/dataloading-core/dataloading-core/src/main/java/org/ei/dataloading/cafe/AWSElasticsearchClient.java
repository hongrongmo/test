package org.ei.dataloading.cafe;

public class AWSElasticsearchClient {

}
