package org.ei.dataloading.xmlDataLoading;

public class Translated_sourcetitle extends BaseElement
{
	String translated_sourcetitle;
	String translated_sourcetitle_lang;

    public void setTranslated_sourcetitle(String translated_sourcetitle)
	{
		this.translated_sourcetitle = translated_sourcetitle;
	}

	public String getTranslated_sourcetitle()
	{
		return this.translated_sourcetitle;
	}

	public void setTranslated_sourcetitle_lang(String translated_sourcetitle_lang)
	{
		this.translated_sourcetitle_lang = translated_sourcetitle_lang;
	}

	public String getTranslated_sourcetitle_lang()
	{
		return this.translated_sourcetitle_lang;
	}
}
