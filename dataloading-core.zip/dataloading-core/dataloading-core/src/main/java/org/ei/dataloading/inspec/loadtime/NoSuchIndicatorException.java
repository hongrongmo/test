package org.ei.dataloading.inspec.loadtime;


public class NoSuchIndicatorException extends Exception{
    public NoSuchIndicatorException() {}
    public NoSuchIndicatorException(String s) {
        super(s);
    }
}
