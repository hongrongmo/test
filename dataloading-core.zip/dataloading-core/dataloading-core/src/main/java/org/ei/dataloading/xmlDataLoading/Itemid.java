package org.ei.dataloading.xmlDataLoading;

public class Itemid extends BaseElement
{

	String itemid;
	String itemid_idtype;

	public void setItemid(String itemid)
	{
		this.itemid = itemid;
	}

	public String getItemid()
	{
		return this.itemid;
	}

	public void setItemid_idtype(String itemid_idtype)
	{
		this.itemid_idtype = itemid_idtype;
	}

	public String getItemid_idtype()
	{
		return this.itemid_idtype;
	}
}
