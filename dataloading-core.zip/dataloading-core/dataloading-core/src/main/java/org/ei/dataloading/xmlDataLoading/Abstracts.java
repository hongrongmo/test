package org.ei.dataloading.xmlDataLoading;

public class Abstracts extends BaseElement
{
	Abstract _abstract;

	public void setAbstract(Abstract _abstract)
	{
		this._abstract = _abstract;
	}

	public Abstract getAbstract()
	{
		return this._abstract;
	}
}
