package org.ei.dataloading.xmlDataLoading;

public class Medium extends BaseElement
{

	String medium;
	String medium_covered;

	public void setMedium(String medium)
	{
		this.medium = medium;
	}

	public String getMedium()
	{
		return medium;
	}

	public void setMedium_covered(String medium_covered)
	{
		this.medium_covered = medium_covered;
	}

	public String getMedium_covered()
	{
		return medium_covered;
	}

}
