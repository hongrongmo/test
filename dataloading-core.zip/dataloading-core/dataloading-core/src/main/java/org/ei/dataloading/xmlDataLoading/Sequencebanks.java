package org.ei.dataloading.xmlDataLoading;

public class Sequencebanks extends BaseElement
{
	Sequencebank sequencebank;


	public void setSequencebank(Sequencebank sequencebank)
	{
		this.sequencebank = sequencebank;
	}

	public Sequencebank getSequencebank()
	{
		return this.sequencebank;
	}

}

