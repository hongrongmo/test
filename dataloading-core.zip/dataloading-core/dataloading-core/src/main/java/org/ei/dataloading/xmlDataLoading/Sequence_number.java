package org.ei.dataloading.xmlDataLoading;

public class Sequence_number extends BaseElement
{
	String sequence_number;
	String sequence_number_type;

	public void setSequence_number(String sequence_number)
	{
		this.sequence_number = sequence_number;
	}

	public String getSequence_number()
	{
		return this.sequence_number;
	}

	public void setSequence_number_type(String sequence_number_type)
	{
		this.sequence_number_type = sequence_number_type;
	}

	public String getSequence_number_type()
	{
		return this.sequence_number_type;
	}

}

