package org.ei.dataloading.xmlDataLoading;

public class Pagecount extends BaseElement

{
	String pagecount;
	String pagecount_type;


	public void setPagecount(String pagecount)
	{
		this.pagecount = pagecount;
	}

	public String getPagecount()
	{
		return this.pagecount;
	}

	public void setPagecount_type(String pagecount_type)
	{
		this.pagecount_type = pagecount_type;
	}

	public String getPagecount_type()
	{
		return this.pagecount_type;
	}

}
