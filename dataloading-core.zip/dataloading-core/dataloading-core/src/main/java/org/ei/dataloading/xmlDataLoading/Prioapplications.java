package org.ei.dataloading.xmlDataLoading;

public class Prioapplications extends BaseElement
{
	String prioapplication;

	public void setPrioapplication(String prioapplication)
	{
		this.prioapplication = prioapplication;
	}

	public String getPrioapplication()
	{
		return this.prioapplication;
	}

}

