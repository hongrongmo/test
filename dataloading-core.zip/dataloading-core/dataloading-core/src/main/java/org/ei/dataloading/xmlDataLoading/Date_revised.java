package org.ei.dataloading.xmlDataLoading;

public class Date_revised extends BaseElement
{
	String date_revised;
	String date_revised_year;
	String date_revised_month;
	String date_revised_day;


	public void setDate_revised(String date_revised)
	{
		this.date_revised = date_revised;
	}

	public String getDate_revised()
	{
		return this.date_revised;
	}

	public void setDate_revised_year(String date_revised_year)
	{
		this.date_revised_year = date_revised_year;
	}

	public String getDate_revised_year()
	{
		return this.date_revised_year;
	}

	public void setDate_revised_month(String date_revised_month)
	{
		this.date_revised_month = date_revised_month;
	}

	public String getDate_revised_month()
	{
		return this.date_revised_month;
	}

	public void setDate_revised_day(String date_revised_day)
	{
		this.date_revised_day = date_revised_day;
	}

	public String getDate_revised_day()
	{
		return this.date_revised_day;
	}

}
