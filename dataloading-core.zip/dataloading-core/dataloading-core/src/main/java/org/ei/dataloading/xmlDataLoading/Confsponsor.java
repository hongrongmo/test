package org.ei.dataloading.xmlDataLoading;

public class Confsponsor extends BaseElement {

    String confsponsor;

    public void setConfsponsor(String confsponsor) {
        this.confsponsor = confsponsor;
    }

    public String getConfsponsor() {
        return confsponsor;
    }

}
