package org.ei.dataloading.xmlDataLoading;

public class Designatedcountries extends BaseElement
{
	String country;

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getCountry()
	{
		return this.country;
	}

}

