package org.ei.dataloading.xmlDataLoading;

public class Ref_info extends BaseElement
{
	Ref_title ref_title;
	Refd_itemidlist refd_itemidlist;
	Ref_authors ref_authors;
	String ref_sourcetitle;
	Ref_publicationyear ref_publicationyear;
	Volisspag ref_volisspag;
	Ref_website ref_website;
	String ref_text;

	public void setRef_title(Ref_title ref_title)
	{
		this.ref_title = ref_title;
	}

	public Ref_title getRef_title()
	{
		return ref_title;
	}

	public void setRefd_itemidlist(Refd_itemidlist refd_itemidlist)
	{
		this.refd_itemidlist = refd_itemidlist;
	}

	public Refd_itemidlist getRefd_itemidlist()
	{
		return refd_itemidlist;
	}

	public void setRef_authors(Ref_authors ref_authors)
	{
		this.ref_authors = ref_authors;
	}

	public Ref_authors getRef_authors()
	{
		return ref_authors;
	}

	public void setRef_sourcetitle(String ref_sourcetitle)
	{
		this.ref_sourcetitle = ref_sourcetitle;
	}

	public String getRef_sourcetitle()
	{
		return ref_sourcetitle;
	}

	public void setRef_publicationyear(Ref_publicationyear ref_publicationyear)
	{
		this.ref_publicationyear = ref_publicationyear;
	}

	public Ref_publicationyear getRef_publicationyear()
	{
		return ref_publicationyear;
	}

	public void setRef_volisspag(Volisspag ref_volisspag)
	{
		this.ref_volisspag = ref_volisspag;
	}

	public Volisspag getRef_volisspag()
	{
		return ref_volisspag;
	}

	public void setRef_website(Ref_website ref_website)
	{
		this.ref_website = ref_website;
	}

	public Ref_website getRef_website()
	{
		return ref_website;
	}

	public void setRef_text(String ref_text)
	{
		this.ref_text = ref_text;
	}

	public String getRef_text()
	{
		return ref_text;
	}

}

