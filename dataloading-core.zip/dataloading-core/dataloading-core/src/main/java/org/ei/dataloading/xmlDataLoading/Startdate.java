package org.ei.dataloading.xmlDataLoading;

public class Startdate extends BaseElement
{

	String startdate;
	String startdate_year;
	String startdate_month;
	String startdate_day;

	public void setStartdate(String startdate)
	{
		this.startdate = startdate;
	}

	public String getStartdate()
	{
		return startdate;
	}

	public void setStartdate_year(String startdate_year)
	{
		this.startdate_year = startdate_year;
	}

	public String getStartdate_year()
	{
		return startdate_year;
	}

	public void setStartdate_month(String startdate_month)
	{
		this.startdate_month = startdate_month;
	}

	public String getStartdate_month()
	{
		return startdate_month;
	}

	public void setStartdate_day(String startdate_day)
		{
			this.startdate_day = startdate_day;
		}

		public String getStartdate_day()
		{
			return startdate_day;
	}




}
