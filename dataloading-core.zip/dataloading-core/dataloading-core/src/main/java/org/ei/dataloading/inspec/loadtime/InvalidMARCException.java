package org.ei.dataloading.inspec.loadtime;


public class InvalidMARCException extends Exception {
    public  InvalidMARCException() {}
    public  InvalidMARCException(String s) {
	super(s);
    }
}
