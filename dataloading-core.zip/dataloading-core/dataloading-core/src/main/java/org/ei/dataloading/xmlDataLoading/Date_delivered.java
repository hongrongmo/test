package org.ei.dataloading.xmlDataLoading;

public class Date_delivered extends BaseElement
{
	String date_delivered;
	String date_delivered_year;
	String date_delivered_month;
	String date_delivered_day;


	public void setDate_delivered(String date_delivered)
	{
		this.date_delivered = date_delivered;
	}

	public String getDate_delivered()
	{
		return this.date_delivered;
	}

	public void setDate_delivered_year(String date_delivered_year)
	{
		this.date_delivered_year = date_delivered_year;
	}

	public String getDate_delivered_year()
	{
		return this.date_delivered_year;
	}

	public void setDate_delivered_month(String date_delivered_month)
	{
		this.date_delivered_month = date_delivered_month;
	}

	public String getDate_delivered_month()
	{
		return this.date_delivered_month;
	}

	public void setDate_delivered_day(String date_delivered_day)
	{
		this.date_delivered_day = date_delivered_day;
	}

	public String getDate_delivered_day()
	{
		return this.date_delivered_day;
	}

}
