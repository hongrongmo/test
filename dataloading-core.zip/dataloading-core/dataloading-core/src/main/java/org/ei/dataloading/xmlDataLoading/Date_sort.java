package org.ei.dataloading.xmlDataLoading;

public class Date_sort extends BaseElement
{

	String date_sort;
	String date_sort_year;
	String date_sort_month;
	String date_sort_day;

	public void setDate_sort(String date_sort)
	{
		this.date_sort = date_sort;
	}

	public String getDate_sort()
	{
		return this.date_sort;
	}

	public void setDate_sort_year(String date_sort_year)
	{
		this.date_sort_year = date_sort_year;
	}

	public String getDate_sort_year()
	{
		return this.date_sort_year;
	}

	public void setDate_sort_month(String date_sort_month)
	{
		this.date_sort_month = date_sort_month;
	}

	public String getDate_sort_month()
	{
		return this.date_sort_month;
	}

	public void setDate_sort_day(String date_sort_day)
	{
		this.date_sort_day = date_sort_day;
	}

	public String getDate_sort_day()
	{
		return this.date_sort_day;
	}

}
